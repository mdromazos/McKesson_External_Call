package com.informatica.mdm.sample.cs;

import java.util.Map;

import org.apache.log4j.Logger;

import com.informatica.mdm.spi.cs.StepException;
import com.informatica.mdm.spi.externalcall.CustomLogic;

import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

public class SetAcctFreightHFC implements CustomLogic {

	public static final Logger log = Logger.getLogger(validateBERules.class);
	public String businessentityName  ="";
	  public SetAcctFreightHFC( String entityName) {      
	    	businessentityName = entityName;
	        log.info(" Constructor called  -- entityName SetAcctFreightHFC: " + businessentityName);  
	        log.debug(" Constructor called debugg -- entityName SetAcctFreightHFC: " + businessentityName);   
	        
	    }
	  public static boolean isEmpty( final String s ) {
		  return s == null || s.trim().isEmpty();
		}
	@Override
	public DataObject process(HelperContext arg0, DataObject arg1, Map<String, Object> arg2, Map<String, Object> arg3)
			throws StepException {
		// TODO Auto-generated method stub
		return null;
	}

}
