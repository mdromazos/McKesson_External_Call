package com.informatica.mdm.sample.cs;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.informatica.mdm.spi.cs.StepException;
import com.informatica.mdm.spi.externalcall.CustomLogic;
import com.informatica.mdm.spi.externalcall.CustomLogicFactory;
import com.informatica.mdm.spi.externalcall.ServicePhase;
import com.informatica.mdm.spi.externalcall.Trigger;
import com.informatica.mdm.spi.externalcall.ExternalCallRequest;
import com.informatica.mdm.cs.client.CompositeServiceClient;
import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

public class CustomLogicFactoryImpl implements CustomLogicFactory {

    public static final String CUSTOMERORG = "ExHFC_HEP_CustomerOrg";

    private static final CustomLogic EMPTY_LOGIC = new EmptyLogic();
    public static final Logger log = Logger.getLogger(CustomLogicFactoryImpl.class); 

    private CompositeServiceClient besClient;

    public CustomLogicFactoryImpl(CompositeServiceClient besClient) {
        this.besClient = besClient;
    }

    @Override
    public CustomLogic create(ExternalCallRequest externalCallRequest) throws StepException {
		// we interested in "Person" Business Entity only and can handle just few servcie phases
        Trigger trigger = externalCallRequest.getTrigger();
        String businessEntity = trigger.getBusinessEntity();
        ServicePhase phase = trigger.getServicePhase();

        switch (phase) {
//            case WRITE_CO_BEFORE_VALIDATE:
//                if (CUSTOMERORG.equals(businessEntity)) {
//                    return new ValidateCustomerOrg();
//                }
//                break;
//            case PREVIEW_MERGE_CO_BEFORE_EVERYTHING:
            case WRITE_CO_BEFORE_VALIDATE:
                if (CUSTOMERORG.equals(businessEntity)) {
                	log.info("CUSTOMERORG IS " + businessEntity);
                	log.debug("CUSTOMERORG debug IS " + businessEntity);
                	log.info("Inside : WRITE_CO_BEFORE_VALIDATE: CustomLogicFactoryImpl ");
                	return new validateBERules(businessEntity);
    }
                break;
            case WRITE_CO_AFTER_VALIDATE:
    			if (CUSTOMERORG.equals(businessEntity)) {
    				log.info("Inside : WRITE_CO_AFTER_VALIDATE: CustomLogicFactoryImpl ");
    			//	return new AfterSaveParty(businessEntity);
    				return new SetAcctFreightHFC(businessEntity);
    			}
    			break;
            default:
            	if (CUSTOMERORG.equals(businessEntity)) {
                  return new Pocclass();
              }
                
        }
        return EMPTY_LOGIC; // this one will do nothing
    }

    private static class EmptyLogic implements CustomLogic {

        public static final DataObject OBJECT = null;

        @Override
        public DataObject process(HelperContext helperContext, DataObject dataObject, Map<String, Object> map,
                Map<String, Object> map1) throws StepException {
            return OBJECT;
        }
    }
}
