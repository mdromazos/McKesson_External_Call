package com.informatica.mdm.sample.cs;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.informatica.mdm.sdo.cs.base.ValidationError;
import com.informatica.mdm.sdo.cs.base.ValidationErrors;
import com.informatica.mdm.spi.cs.StepException;
import com.informatica.mdm.spi.externalcall.CustomLogic;
import com.siperian.sif.client.SiperianClient;

import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.helper.DataFactory;
import commonj.sdo.helper.HelperContext;

/**
 * This is piece of logic for validating "Person" Business Entity.
 * All we do here is force user to provide at least one Address for the Person.
 */
public class ValidateCustomerOrg implements CustomLogic  {
	
	


    @Override
    public DataObject process(HelperContext helperContext, DataObject inputSdo,
            Map<String, Object> inParams,
            Map<String, Object> outParams) throws StepException {
    	
    	//Error Initialization
    	List<ValidationError> errorList = new ArrayList<>();
    	DataFactory dataFactory = helperContext.getDataFactory();
        ValidationError error = (ValidationError) dataFactory.create(ValidationError.class);
        ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
    	
    	System.out.println("Customer Org before Validate");
    	
    	String xml = helperContext.getXMLHelper().save(
    			inputSdo,
    			inputSdo.getType().getURI(),
    			inputSdo.getType().getName());
    	System.out.println("XML String of Input SDO is "+xml);
    	
    	System.out.println("Printing inparams");
        for (String name : inParams.keySet())  
            System.out.println("key: " + name); 
        for (Object params : inParams.values())  
            System.out.println("value: " + params.toString()); 
        
        System.out.println("Printing outparams");
        for (String name : outParams.keySet())  
            System.out.println("key: " + name); 
        for (Object params : outParams.values())  
            System.out.println("value: " + params.toString()); 
    	
    	System.out.println("Starting with Change Summary Printing");
		ChangeSummary cs = inputSdo.getChangeSummary();
		Map<String, DataObject> csMap = new HashMap<>();
		List<String> csCreatedList = new ArrayList<>();
		List<String> csDeletedList = new ArrayList<>();
		List<String> csModifiedList = new ArrayList<>();
    	@SuppressWarnings("unchecked")
		List<DataObject> csList = cs.getChangedDataObjects();
    	if (csList != null && !csList.isEmpty()) {
    		System.out.println("Change Summary size is "+csList.size());
    		for (int csindex = 0; csindex < csList.size(); csindex++) { 
    			DataObject csdo = (DataObject) csList.get(csindex);
//    	        String brRowid = br.getString("RemitTo/rowidObject");
//    	        System.out.println("Rowid Object of Business Rel DO "+brindex+" is "+brRowid);
//    			String sdoName = csdo.getType().getName();
//    			String sdoURI = csdo.getType().getURI();
//    			System.out.println("SDO Name is "+sdoName);
//    			System.out.println("SDO Type is "+sdoURI);
    			xml = helperContext.getXMLHelper().save(
    					csdo,
    					csdo.getType().getURI(),
    					csdo.getType().getName());
    	    	System.out.println("XML String of CS SDO "+csindex+"is "+xml);
    			String sdoName = csdo.getType().getName();
    			System.out.println("SDO Name is "+sdoName);
    			if(inputSdo.getChangeSummary().isCreated(csdo)) {
    				System.out.println(sdoName+" is Created");
    				csMap.put(sdoName+"-Created",csdo);
    				csCreatedList.add(sdoName);
    			}
    			if(inputSdo.getChangeSummary().isDeleted(csdo)) {
    				System.out.println(sdoName+" is Deleted");
    				csMap.put(sdoName+"-Deleted",csdo);
    				csDeletedList.add(sdoName);
    			}
    			if(inputSdo.getChangeSummary().isModified(csdo)) {
    				System.out.println(sdoName+" is Modified");
    				csMap.put(sdoName+"-Modified",csdo);
    				csModifiedList.add(sdoName);
    			}
    			
    	    }
    	}
    	System.out.println("Completed Printing Change Summary");
        
        if (csList != null && !csList.isEmpty()) {
        	//New Vendor Creation Validation
	        if (csCreatedList.contains("CustomerOrg.Root")) {
	        	//Business Relationship Validation
	        	@SuppressWarnings("unchecked")
				List<?> newBusinessRelList = inputSdo.getList("CustomerOrg/BusinessRelationship/item");
	        	if ((newBusinessRelList == null) || newBusinessRelList.isEmpty()) {
	        		error.setCode("CUSTOM-00001");
                    error.setMessage("New Vendor should have atleast one Company Code Information");
                    error.setField(Collections.singletonList("CustomerOrg.BusinessRelationship"));
                    errorList.add(error);
                    errors.setError(errorList);
                    throw new StepException((DataObject) errors, "SIP-50022");
	        	}
//	        	else {
//	        		//Remit To and Order From validation
//	        		for (int brindex = 0; brindex < newBusinessRelList.size(); brindex++) { 
//	        			DataObject br = (DataObject) newBusinessRelList.get(brindex);
//	        			xml = helperContext.getXMLHelper().save(
//	        					br,
//	        					br.getType().getURI(),
//	        					br.getType().getName());
//	        	    	System.out.println("XML String of Input SDO is "+xml);
//	        			List<?> newRemitToList = inputSdo.getList("CustomerOrg/BusinessRelationship["+(brindex+1)+"]/RemitTo/item");
//	        			List<?> newOrderFromList = br.getList("CustomerOrg.BusinessRelationship/OrderFrom/item");
//	        			if (((newRemitToList == null) || newRemitToList.isEmpty()) && ((newOrderFromList == null) || newOrderFromList.isEmpty())) {
//	        				error.setCode("CUSTOM-00001");
//		                    error.setMessage("Business Relationship should have atleast one OA or PI");
//		                    error.setField(Collections.singletonList("CustomerOrg.BusinessRelationship"));
//		                    errorList.add(error);
//		                    errors.setError(errorList);
//	                        throw new StepException((DataObject) errors, "SIP-50022");
//	    	        	}
//	        	    }
//	        	}
	        	// Tax Validation
	        	@SuppressWarnings("unchecked")
				List<?> newTaxList = inputSdo.getList("CustomerOrg/Tax/item");
	        	if ((newTaxList == null) || newTaxList.isEmpty()) {
	        		error.setCode("CUSTOM-00001");
                    error.setMessage("New Vendor should have atleast one Tax Information");
                    error.setField(Collections.singletonList("CustomerOrg.Tax"));
                    errorList.add(error);
                    errors.setError(errorList);
                    throw new StepException((DataObject) errors, "SIP-50022");
	        	}
	        	
	        
	        }
	        //Change Vendor Validations
	        else {
	        	//Remit To Address Change
	        	if(csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToAddress")) {
	            	System.out.println("Remit To Address has been changed");
	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
	            		System.out.println("Active Request is not Available");
	            	  error.setCode("CUSTOM-00004");
	                  error.setMessage("No Active Request for Remit To Address Change");
	                  error.setField(Collections.singletonList("CustomerOrg.Request"));
	                  errorList.add(error);
	                  errors.setError(errorList);
                      throw new StepException((DataObject) errors, "SIP-50022");
	            	}
	            	else {
	            		System.out.println("Active Request is Available");
	            		String isAddressChangeSelected = null;
	            		isAddressChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("AddressChange");
	            		if(isAddressChangeSelected == null || isAddressChangeSelected.isEmpty()) {
	            			System.out.println("Active Request is not having Remit To Address Change - 1");
	            			error.setCode("CUSTOM-00004");
	                        error.setMessage("Active Request is not having Remit To Address Change");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            		else if(!isAddressChangeSelected.equals("1")) {
	            			System.out.println("Active Request is not having Remit To Address Change - 2");
	            			error.setCode("CUSTOM-00004");
	                        error.setMessage("Active Request is not having Remit To Address Change");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            			
	            	}
	            }
	        	//Remit To Banking Change
	            if(csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToBank")) {
	            	System.out.println("Remit To Banking has been changed");
	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
	            		System.out.println("Active Request is not Available");
	            	  error.setCode("CUSTOM-00005");
	                  error.setMessage("No Active Request for Remit To Banking Change");
	                  error.setField(Collections.singletonList("CustomerOrg.Request"));
	                  errorList.add(error);
	                  errors.setError(errorList);
                      throw new StepException((DataObject) errors, "SIP-50022");
	            	}
	            	else {
	            		System.out.println("Active Request is Available");
	            		String isBankingChangeSelected = null;
	            		isBankingChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("BankingChange");
	            		if(isBankingChangeSelected == null || isBankingChangeSelected.isEmpty()) {
	            			System.out.println("Active Request is not having Remit To Banking Change - 1");
	            			error.setCode("CUSTOM-00005");
	                        error.setMessage("Active Request is not having Remit To Banking Change");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            		else if(!isBankingChangeSelected.equals("1")) {
	            			System.out.println("Active Request is not having Remit To Banking Change - 2");
	            			error.setCode("CUSTOM-00005");
	                        error.setMessage("Active Request is not having Remit To Banking Change");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            			
	            	}
	            }
	            //Remit To Payment Details
	            if(csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails")) {
	            	System.out.println("Remit To Payment Details has been changed");
	            	String isPaymentTermChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentTerm/PaymentTermCd");
	            	String isPaymentMethodChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentMethod/PaymentMethodCd");
	            	//Payment Term Change
	            	if(isPaymentTermChanged == null || isPaymentTermChanged.isEmpty()) {
		            	if(!csCreatedList.contains("CustomerOrg.Request")) {
		            		System.out.println("Active Request is not Available");
		            	  error.setCode("CUSTOM-00006");
		                  error.setMessage("No Active Request for Remit To Payment Term Change");
		                  error.setField(Collections.singletonList("CustomerOrg.Request"));
		                  errorList.add(error);
		                  errors.setError(errorList);
	                      throw new StepException((DataObject) errors, "SIP-50022");
		            	}
		            	else {
		            		System.out.println("Active Request is Available");
		            		String isPaymentTermChangeSelected = null;
		            		isPaymentTermChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("PaymentTermChange");
		            		if(isPaymentTermChangeSelected == null || isPaymentTermChangeSelected.isEmpty()) {
		            			System.out.println("Active Request is not having Remit To Payment Details Change - 1");
		            			error.setCode("CUSTOM-00006");
		                        error.setMessage("Active Request is not having Remit To Payment Details Change");
		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
		                        errorList.add(error);
		                        errors.setError(errorList);
		                        throw new StepException((DataObject) errors, "SIP-50022");
		            		}
		            		else if(!isPaymentTermChangeSelected.equals("1")) {
		            			System.out.println("Active Request is not having Remit To Payment Details Change - 2");
		            			error.setCode("CUSTOM-00006");
		                        error.setMessage("Active Request is not having Remit To Payment Details Change");
		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
		                        errorList.add(error);
		                        errors.setError(errorList);
		                        throw new StepException((DataObject) errors, "SIP-50022");
		            		}
		            			
		            	}
	            	}
	            	//Payment Method Change
	            	if(isPaymentMethodChanged == null || isPaymentMethodChanged.isEmpty()) {
		            	if(!csCreatedList.contains("CustomerOrg.Request")) {
		            		System.out.println("Active Request is not Available");
		            	  error.setCode("CUSTOM-00006");
		                  error.setMessage("No Active Request for Remit To Payment Method Change");
		                  error.setField(Collections.singletonList("CustomerOrg.Request"));
		                  errorList.add(error);
		                  errors.setError(errorList);
	                       throw new StepException((DataObject) errors, "SIP-50022");
		            	}
		            	else {
		            		System.out.println("Active Request is Available");
		            		String isPaymentTermChangeSelected = null;
		            		isPaymentTermChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("PaymentChange");
		            		if(isPaymentTermChangeSelected == null || isPaymentTermChangeSelected.isEmpty()) {
		            			System.out.println("Active Request is not having Remit To Payment Method Change - 1");
		            			error.setCode("CUSTOM-00006");
		                        error.setMessage("Active Request is not having Remit To Payment Method Change");
		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
		                        errorList.add(error);
		                        errors.setError(errorList);
		                        throw new StepException((DataObject) errors, "SIP-50022");
		            		}
		            		else if(!isPaymentTermChangeSelected.equals("1")) {
		            			System.out.println("Active Request is not having Remit To Payment Method Change - 2");
		            			error.setCode("CUSTOM-00006");
		                        error.setMessage("Active Request is not having Remit To Payment Method Change");
		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
		                        errorList.add(error);
		                        errors.setError(errorList);
		                        throw new StepException((DataObject) errors, "SIP-50022");
		            		}
		            			
		            	}
	            	}
	            }
	            // Order From Address Change
	            if(csModifiedList.contains("CustomerOrg.BusinessRelationship.OrderFrom.OrderFromAddress")) {
	            	System.out.println("Order From Address has been changed");
	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
	            		System.out.println("Active Request is not Available");
	            	  error.setCode("CUSTOM-00007");
	                  error.setMessage("No Active Request for Order From Address Change");
	                  error.setField(Collections.singletonList("CustomerOrg.Request"));
	                  errorList.add(error);
	                  errors.setError(errorList);
                      throw new StepException((DataObject) errors, "SIP-50022");
	            	}
	            	else {
	            		System.out.println("Active Request is Available");
	            		String isAddressChangeSelected = null;
	            		isAddressChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("AddressChange");
	            		if(isAddressChangeSelected == null || isAddressChangeSelected.isEmpty()) {
	            			System.out.println("Active Request is not having Order From Address Change - 1");
	            			error.setCode("CUSTOM-00007");
	                        error.setMessage("Active Request is not having Order From Address Change");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            		else if(!isAddressChangeSelected.equals("1")) {
	            			System.out.println("Active Request is not having Order From Address Change - 2");
	            			error.setCode("CUSTOM-00007");
	                        error.setMessage("Active Request is not having Order From Address Change");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            			
	            	}
	            }
	            // Additional Order From
	            if(csCreatedList.contains("CustomerOrg.BusinessRelationship.OrderFrom")) {
	            	System.out.println("Additional Order From Address has been Created");
	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
	            		System.out.println("Active Request is not Available");
	            	  error.setCode("CUSTOM-00008");
	                  error.setMessage("No Active Request for Additional Order From");
	                  error.setField(Collections.singletonList("CustomerOrg.Request"));
	                  errorList.add(error);
	                  errors.setError(errorList);
                      throw new StepException((DataObject) errors, "SIP-50022");
	            	}
	            	else {
	            		System.out.println("Active Request is Available");
	            		String isAdditionalOFSelected = null;
	            		isAdditionalOFSelected = csMap.get("CustomerOrg.Request-Created").getString("AdditionalOF");
	            		if(isAdditionalOFSelected == null || isAdditionalOFSelected.isEmpty()) {
	            			System.out.println("Active Request is not having Additional Order From - 1");
	            			error.setCode("CUSTOM-00008");
	                        error.setMessage("Active Request is not having Additional Order From");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            		else if(!isAdditionalOFSelected.equals("1")) {
	            			System.out.println("Active Request is not having Additional Order From - 2");
	            			error.setCode("CUSTOM-00008");
	                        error.setMessage("Active Request is not having Additional Order From");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            			
	            	}
	            }
	            //Additional Remit To
	            if(csCreatedList.contains("CustomerOrg.BusinessRelationship.RemitTo")) {
	            	System.out.println("Additional Remit To Address has been Created");
	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
	            		System.out.println("Active Request is not Available");
	            	  error.setCode("CUSTOM-00009");
	                  error.setMessage("No Active Request for Additional Remit To");
	                  error.setField(Collections.singletonList("CustomerOrg.Request"));
	                  errorList.add(error);
	                  errors.setError(errorList);
                      throw new StepException((DataObject) errors, "SIP-50022");
	            	}
	            	else {
	            		System.out.println("Active Request is Available");
	            		String isAdditionalRTSelected = null;
	            		isAdditionalRTSelected = csMap.get("CustomerOrg.Request-Created").getString("AdditionalRT");
	            		if(isAdditionalRTSelected == null || isAdditionalRTSelected.isEmpty()) {
	            			System.out.println("Active Request is not having Additional Remit To - 1");
	            			error.setCode("CUSTOM-00009");
	                        error.setMessage("Active Request is not having Additional Remit To");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            		else if(!isAdditionalRTSelected.equals("1")) {
	            			System.out.println("Active Request is not having Additional Remit To - 2");
	            			error.setCode("CUSTOM-00009");
	                        error.setMessage("Active Request is not having Additional Remit To");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            			
	            	}
	            }
	            //Extend Vendor
	            if(csCreatedList.contains("CustomerOrg.BusinessRelationship")) {
	            	System.out.println("New Business Relationship has been Created");
	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
	            		System.out.println("Active Request is not Available");
	            	  error.setCode("CUSTOM-00009");
	                  error.setMessage("No Active Request for Extend Vendor");
	                  error.setField(Collections.singletonList("CustomerOrg.Request"));
	                  errorList.add(error);
	                  errors.setError(errorList);
                      throw new StepException((DataObject) errors, "SIP-50022");
	            	}
	            	else {
	            		System.out.println("Active Request is Available");
	            		String isExtendVendorSelected = null;
	            		isExtendVendorSelected = csMap.get("CustomerOrg.Request-Created").getString("ExtendVendor");
	            		if(isExtendVendorSelected == null || isExtendVendorSelected.isEmpty()) {
	            			System.out.println("Active Request is not having Extend Vendor - 1");
	            			error.setCode("CUSTOM-00009");
	                        error.setMessage("Active Request is not having Extend Vendor");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            		else if(!isExtendVendorSelected.equals("1")) {
	            			System.out.println("Active Request is not having Extend Vendor - 2");
	            			error.setCode("CUSTOM-00009");
	                        error.setMessage("Active Request is not having Extend Vendor");
	                        error.setField(Collections.singletonList("CustomerOrg.Request"));
	                        errorList.add(error);
	                        errors.setError(errorList);
	                        throw new StepException((DataObject) errors, "SIP-50022");
	            		}
	            			
	            	}
	            }
	            //Request to Change Validation
//	            if(csCreatedList.contains("CustomerOrg.Request")) {
//	            	DataObject requestDO = csMap.get("CustomerOrg.Request-Created");
//		            String additionalRT = requestDO.getString("AdditionalRT");
//		            String additionalOF = requestDO.getString("AdditionalOF");
//		            String addressChange = requestDO.getString("AddressChange");
//		            String paymentTermChange = requestDO.getString("PaymentTermChange");
//		            String paymentMethodChange = requestDO.getString("PaymentChange");
//		            String extendVendor = requestDO.getString("ExtendVendor");
//		            String bankingChange = requestDO.getString("BankingChange");
//		            // Additional Remit To Ticket with No new Remit To
//		            if(!(additionalRT == null || additionalRT.isEmpty())) {
//		            	if ( additionalRT.equals("1")) {
//		            		if ( !csCreatedList.contains("CustomerOrg.BusinessRelationship.RemitTo")) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Additional Remit To Option Checked but No new Remit To Details has been added");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//		            // Additional Order From Ticket with No new Order From
//		            if(!(additionalOF == null || additionalOF.isEmpty())) {
//		            	if ( additionalOF.equals("1")) {
//		            		if ( !csCreatedList.contains("CustomerOrg.BusinessRelationship.OrderFrom")) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Additional Order From Option Checked but No new Order From Details has been added");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//		            // Address Change Ticket with No Address Change
//		            if(!(addressChange == null || addressChange.isEmpty())) {
//		            	if ( addressChange.equals("1")) {
//		            		if ( !csModifiedList.contains("CustomerOrg.BusinessRelationship.OrderFrom.OrderFromAddress") && !csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToAddress" )) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Address Change Option Checked but No Address Details has been Changed");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//		            // Payment Term Ticket with No Payment Term Change
//		            if(!(paymentTermChange == null || paymentTermChange.isEmpty())) {
//		            	if ( paymentTermChange.equals("1")) {
//		            		String isPaymentTermChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentTerm/PaymentTermCd");
//		            		if ( isPaymentTermChanged == null || isPaymentTermChanged.isEmpty()) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Payment Term Change Option Checked but No Payment Term Details has been Changed");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//		            // Payment Method Ticket with No Payment Method Change
//		            if(!(paymentMethodChange == null || paymentMethodChange.isEmpty())) {
//		            	if ( paymentMethodChange.equals("1")) {
//		            		String isPaymentMethodChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentMethod/PaymentMethodCd");
//		            		if ( isPaymentMethodChanged == null || isPaymentMethodChanged.isEmpty()) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Payment Method Change Option Checked but No Payment Method Details has been Changed");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//		            // Extend Vendor Ticket with No new Business Rel Record
//		            if(!(extendVendor == null || extendVendor.isEmpty())) {
//		            	if ( extendVendor.equals("1")) {
//		            		if ( !csCreatedList.contains("CustomerOrg.BusinessRelationship")) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Extend Vendor Option Checked but No new Extend Vendor Details has been added");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//		            // Banking Change Ticket with No Banking Information Changed
//		            if(!(bankingChange == null || bankingChange.isEmpty())) {
//		            	if ( bankingChange.equals("1")) {
//		            		if ( !csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToBank")) {
//		            			error.setCode("CUSTOM-00010");
//		                        error.setMessage("Active Request has Banking Change Option Checked but no Banking Details has been Changed");
//		                        error.setField(Collections.singletonList("CustomerOrg.Request"));
//		                        errorList.add(error);
//		                        errors.setError(errorList);
//		                        throw new StepException((DataObject) errors, "SIP-50022");
//		            		}
//		            	}
//		            }
//	            }
	        }
        }
        
        return null;
        
//        errors.setError(errorList);
//        if (errorList.size()==0)
//        	return null;
//        else
//        	throw new StepException((DataObject) errors, "SIP-50022");
        
    }
}


