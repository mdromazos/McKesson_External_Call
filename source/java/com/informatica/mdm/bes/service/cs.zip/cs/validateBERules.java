package com.informatica.mdm.sample.cs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.informatica.mdm.sdo.cs.base.ValidationError;
import com.informatica.mdm.sdo.cs.base.ValidationErrors;
import com.informatica.mdm.spi.cs.StepException;
import com.informatica.mdm.spi.externalcall.CustomLogic;

import commonj.sdo.ChangeSummary;
import commonj.sdo.DataObject;
import commonj.sdo.helper.DataFactory;
import commonj.sdo.helper.HelperContext;

public class validateBERules implements CustomLogic {
	public static final Logger log = Logger.getLogger(validateBERules.class);
	public String businessentityName  ="";
	  public validateBERules( String entityName) {      
	    	businessentityName = entityName;
	        log.info(" Constructor called  -- entityName: " + businessentityName);  
	        log.debug(" Constructor called debugg -- entityName: " + businessentityName);   
	        
	    }
	  public static boolean isEmpty( final String s ) {
		  return s == null || s.trim().isEmpty();
		}
	public DataObject process(HelperContext helperContext, DataObject inputSdo,
            Map<String, Object> inParams,
            Map<String, Object> outParams)
			throws StepException {
		// TODO Auto-generated method stub
		log.info("Printing inparams");
		log.debug("Printing inparams debug");
		DataFactory dataFactory = helperContext.getDataFactory();
		log.info("Printing inparams");
        for (String name : inParams.keySet())  
            log.info("key: " + name); 
        for (Object params : inParams.values())  
            log.info("value: " + params.toString()); 
        
        log.info("Printing outparams");
        for (String name : outParams.keySet())  
            log.info("key: " + name); 
        for (Object params : outParams.values())  
            log.info("value: " + params.toString()); 
        
        String xml = helperContext.getXMLHelper().save(
    			inputSdo,
    			inputSdo.getType().getURI(),
    			inputSdo.getType().getName());
    	log.info("XML String of Input SDO is "+xml);
    	
    	
    	log.info("Starting with Change Summary Printing");
		ChangeSummary cs = inputSdo.getChangeSummary();
		Map<String, DataObject> csMap = new HashMap<>();
		List<String> csCreatedList = new ArrayList<>();
		List<String> csDeletedList = new ArrayList<>();
		List<String> csModifiedList = new ArrayList<>();
    	@SuppressWarnings("unchecked")
		List<DataObject> csList = cs.getChangedDataObjects();
    	

    	List<DataObject> PrimCommList  = new ArrayList<>();
		List<DataObject> PrimList  = new ArrayList<>();
		List<DataObject> OrderFromAddress  = new ArrayList<>();
		List<DataObject> RemitToAddress  = new ArrayList<>();
		
		if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
			PrimList = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExPrimaryCommunication/item");
			PrimCommList = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExPrimaryCommunication/ExPrimaryAddress/item");
			OrderFromAddress = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExBusinessRelationship/ExOrderFrom/ExOrderFromAddress/item");
			RemitToAddress = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExBusinessRelationship/ExRemitTo/ExRemitToAddress/item");
		}
		
		if ((PrimCommList == null) || PrimCommList.isEmpty()) {
			System.out.println("No PrimCommList Child -1");
			// Getting error message

			log.info("PrimCommList::" + PrimCommList);
		} else if (PrimCommList != null) {
			System.out.println("Getting PrimCommList:"+ PrimCommList.size());
			String validmesg="Valid";
			//List trafficEBSMap = inputSdo.getList("Agency/Address/item");
			if (PrimCommList != null && PrimCommList.size() > 0) {
				log.info(" PrimCommList found::" + PrimCommList.size());
				for (int i = 0; i < PrimCommList.size(); i++) {
					DataObject Primaddress = (DataObject) PrimCommList.get(i);
					validmesg = Primaddress.getString("ExIsValid");
					log.info(" validmesg found::" + validmesg);
					if (validmesg.contains("Invalid"))
					{
						log.info("validmesg Invalid throw error ::" + validmesg);
						String validateCustomerError ="SIP-888801$Enter the Reason for Invalid Address";
						if (!isEmpty(validateCustomerError)) {
							dataFactory = helperContext.getDataFactory();
							List<ValidationError> custErrorList = new ArrayList<>();

							ValidationError custError = (ValidationError) dataFactory.create(ValidationError.class);
							custError.setCode(validateCustomerError.substring(0,	validateCustomerError.indexOf("$")));
							custError.setMessage(validateCustomerError.substring(validateCustomerError.lastIndexOf("$") + 1));
							if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
							custError.setField(Collections.singletonList("ExHFC_HEP_CustomerOrg.ExPrimaryCommunication"));
							}
							custErrorList.add(custError);
							log.info("errorList ::" + custErrorList);
							ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
							errors.setError(custErrorList);
							throw new StepException((DataObject) errors,"SIP-50022");
						}
					}
					
				}
			}
		}
		
		// OrderFromAddress
		
		if ((OrderFromAddress == null) || OrderFromAddress.isEmpty()) {
			System.out.println("No OrderFromAddress Child -1");
			// Getting error message

			log.info("OrderFromAddress::" + OrderFromAddress);
		} else if (OrderFromAddress != null) {
			System.out.println("Getting OrderFromAddress:"+ OrderFromAddress.size());
			String validmesg="Valid";
			//List trafficEBSMap = inputSdo.getList("Agency/Address/item");
			if (OrderFromAddress != null && OrderFromAddress.size() > 0) {
				log.info(" OrderFromAddress found::" + OrderFromAddress.size());
				for (int i = 0; i < OrderFromAddress.size(); i++) {
					DataObject orderaddress = (DataObject) OrderFromAddress.get(i);
					validmesg = orderaddress.getString("ExIsValid");
					log.info(" validmesg found::" + validmesg);
					if (validmesg.contains("Invalid"))
					{
						log.info("validmesg Invalid throw error ::" + validmesg);
						String validateCustomerError ="SIP-888801$Enter the Reason for Invalid Address";
						if (!isEmpty(validateCustomerError)) {
							dataFactory = helperContext.getDataFactory();
							List<ValidationError> custErrorList = new ArrayList<>();

							ValidationError custError = (ValidationError) dataFactory.create(ValidationError.class);
							custError.setCode(validateCustomerError.substring(0,	validateCustomerError.indexOf("$")));
							custError.setMessage(validateCustomerError.substring(validateCustomerError.lastIndexOf("$") + 1));
							if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
							custError.setField(Collections.singletonList("ExHFC_HEP_CustomerOrg.ExBusinessRelationship"));
							}
							custErrorList.add(custError);
							log.info("errorList ::" + custErrorList);
							ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
							errors.setError(custErrorList);
							throw new StepException((DataObject) errors,"SIP-50022");
						}
					}
					
				}
			}
		}
		
		//
		
		// RemitTO
		
				if ((RemitToAddress == null) || RemitToAddress.isEmpty()) {
					System.out.println("No RemitToAddress Child -1");
					// Getting error message

					log.info("RemitToAddress::" + RemitToAddress);
				} else if (RemitToAddress != null) {
					System.out.println("Getting RemitToAddress:"+ RemitToAddress.size());
					String validmesg="Valid";
					//List trafficEBSMap = inputSdo.getList("Agency/Address/item");
					if (RemitToAddress != null && RemitToAddress.size() > 0) {
						log.info(" RemitToAddress found::" + RemitToAddress.size());
						for (int i = 0; i < RemitToAddress.size(); i++) {
							DataObject orderaddress = (DataObject) RemitToAddress.get(i);
							validmesg = orderaddress.getString("ExIsValid");
							log.info(" validmesg found::" + validmesg);
							if (validmesg.contains("Invalid"))
							{
								log.info("validmesg Invalid throw error ::" + validmesg);
								String validateCustomerError ="SIP-888801$Enter the Reason for Invalid Address";
								if (!isEmpty(validateCustomerError)) {
									dataFactory = helperContext.getDataFactory();
									List<ValidationError> custErrorList = new ArrayList<>();

									ValidationError custError = (ValidationError) dataFactory.create(ValidationError.class);
									custError.setCode(validateCustomerError.substring(0,	validateCustomerError.indexOf("$")));
									custError.setMessage(validateCustomerError.substring(validateCustomerError.lastIndexOf("$") + 1));
									if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
									custError.setField(Collections.singletonList("ExHFC_HEP_CustomerOrg.ExBusinessRelationship"));
									}
									custErrorList.add(custError);
									log.info("errorList ::" + custErrorList);
									ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
									errors.setError(custErrorList);
									throw new StepException((DataObject) errors,"SIP-50022");
								}
							}
							
						}
					}
				}
				
			
				String pymntvalue ="";
				// Paymment method validation
				List<DataObject> PaymentMethdType  = new ArrayList<>();
				boolean checkbankdetails=false;
				
				if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
					
					PaymentMethdType = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExBusinessRelationship/ExRemitTo/ExRemitToPaymentDtls/item");
				}
				
				if ((PaymentMethdType == null) || PaymentMethdType.isEmpty()) {
					System.out.println("No PaymentMethdType Child -1");
					// Getting error message

					log.info("PaymentMethdType::" + PaymentMethdType);
				} else if (PaymentMethdType != null) 
				{
					System.out.println("Getting Traffic Ebs Map:"+ PaymentMethdType.size());
					String Payment;
					//List trafficEBSMap = inputSdo.getList("Agency/Address/item");
					if (PaymentMethdType != null && PaymentMethdType.size() > 0) {
						System.out.println(" EBS Map  found::" + PaymentMethdType.size());
						for (int i = 0; i < PaymentMethdType.size(); i++) {
							DataObject paymentlkp = (DataObject) PaymentMethdType.get(i);
				
				DataObject PymntMethdLkp = paymentlkp.getDataObject("ExPymntMethod");
			
				if (PymntMethdLkp != null) {	
					pymntvalue =PymntMethdLkp.getString("PaymentMethodCd"); 
					log.info("pymntvalue  ::" + pymntvalue);
					if (pymntvalue.equalsIgnoreCase("HFC_HEP - D") || pymntvalue.equalsIgnoreCase("HFC_HEP - W"))
					{
						log.info("pymntvalue  ::" + pymntvalue);	
						checkbankdetails=true;
					}
				}
				
						}
					}
				}
				// Get RemitToBank details
				
				String bankctry ="";
				String bankrtg="";
				String bankacct="";
				String Bankname="";
				String Swift="";
				boolean err=false;
				List<DataObject> RemitToBankdtl  = new ArrayList<>();
				log.info("checkbankdetails  ::" + checkbankdetails);
				//only if checkbank details is true
				
				if (checkbankdetails)
				{
					if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
						
						RemitToBankdtl = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExBusinessRelationship/ExRemitTo/ExRemitToBank/item");
					}
					
					if ((RemitToBankdtl == null) || RemitToBankdtl.isEmpty()) {
						System.out.println("No RemitToBankdtl Child -1");
						// Getting error message

						log.info("RemitToBankdtl::" + RemitToBankdtl);
					} else if (RemitToBankdtl != null) {
						System.out.println("Getting RemitToBankdtl:"+ RemitToBankdtl.size());
						
						//List trafficEBSMap = inputSdo.getList("Agency/Address/item");
						if (RemitToBankdtl != null && RemitToBankdtl.size() > 0) {
							System.out.println(" EBS Map  found::" + RemitToBankdtl.size());
							for (int j = 0; j < RemitToBankdtl.size(); j++) {
								DataObject remitdtls = (DataObject) RemitToBankdtl.get(j);
								Swift = remitdtls.getString("ExSwift");
								Bankname = remitdtls.getString("ExBankName");
								bankacct = remitdtls.getString("ExBankAccNum");
								bankrtg = remitdtls.getString("ExBankRouting");
								DataObject bnkctry = remitdtls.getDataObject("ExBankCntry");
								if (bnkctry != null) {	
									bankctry =bnkctry.getString("PaymentMethodCd"); 
									log.info("bankctry  ::" + bankctry);
									
								}
								else
								{
									log.info("bankctry is null  ::" + bankctry);
									err =true;
								}
								
								if ((Swift == null) || (Bankname == null) || (bankacct == null) || (bnkctry == null))
								{
									log.info("Null fields: Error ");
									String validateCustomerError ="SIP-888801$Bank Ctry, Bank Account, Swift and bank Country Cannot be Null";
									if (!isEmpty(validateCustomerError)) {
										dataFactory = helperContext.getDataFactory();
										List<ValidationError> custErrorList = new ArrayList<>();

										ValidationError custError = (ValidationError) dataFactory.create(ValidationError.class);
										custError.setCode(validateCustomerError.substring(0,	validateCustomerError.indexOf("$")));
										custError.setMessage(validateCustomerError.substring(validateCustomerError.lastIndexOf("$") + 1));
										if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
										custError.setField(Collections.singletonList("ExHFC_HEP_CustomerOrg.ExBusinessRelationship"));
										}
										custErrorList.add(custError);
										log.info("errorList ::" + custErrorList);
										ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
										errors.setError(custErrorList);
										throw new StepException((DataObject) errors,"SIP-50022");
									}
									
								}
								
							}
						}
					
				}
				
				}
	
				// Annual Spend validation
				
				List<DataObject> PurchaseOrgs  = new ArrayList<>();
				List<DataObject> CustOrgList  = new ArrayList<>();
				
				if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
					PurchaseOrgs = inputSdo.getList("ExHFC_HEP_CustomerOrg/ExBusinessRelationship/ExPurchaseOrgs/item");
				}	
				
				// get vendor type
				
				CustOrgList = inputSdo.getList("ExHFC_HEP_CustomerOrg/item");
				
				String vndrtype="";
				
				if ((CustOrgList == null) || CustOrgList.isEmpty()) {
					System.out.println("No RemitToBankdtl Child -1");
					// Getting error message

					log.info("CustOrgList::" + CustOrgList);
				} 
				else if (CustOrgList != null)
				{
					System.out.println(" CustOrgList found::" + CustOrgList.size());
					for (int j = 0; j < CustOrgList.size(); j++) {
						DataObject vendor = (DataObject) CustOrgList.get(j);
						
					
						DataObject vndrflag = vendor.getDataObject("ExVendorType");
						if (vndrflag != null) {	
							vndrtype =vndrflag.getString("FlagVal"); 
							log.info("vndrtype  ::" + vndrtype);
							
						}
				}
				}
				
				if ((PurchaseOrgs == null) || PurchaseOrgs.isEmpty()) {
					System.out.println("No RemitToBankdtl Child -1");
					// Getting error message

					log.info("PurchaseOrgs::" + PurchaseOrgs);
				} else if (PurchaseOrgs != null) {
					System.out.println("Getting RemitToBankdtl:"+ PurchaseOrgs.size());
					
					if (PurchaseOrgs != null && PurchaseOrgs.size() > 0) {
						System.out.println(" PurchaseOrgs found::" + PurchaseOrgs.size());
						for (int j = 0; j < PurchaseOrgs.size(); j++) {
							DataObject puchasedet = (DataObject) PurchaseOrgs.get(j);
							String flagval="";
							String anspend="";
							String vndcat="";
							DataObject lkpflag = puchasedet.getDataObject("ExSpendCommitedFlag");
							if (lkpflag != null) {	
								flagval =lkpflag.getString("FlagVal"); 
								log.info("bankctry  ::" + bankctry);
								
							}
							
							DataObject lkpannspend = puchasedet.getDataObject("ExAnnualSpend");
							if (lkpannspend != null) {	
								anspend =lkpannspend.getString("AnnualSpend"); 
								log.info("anspend  ::" + anspend);
								
							}
							
							DataObject vndrcatg = puchasedet.getDataObject("ExVendorCategory");
							if (vndrcatg != null) {	
								vndcat =vndrcatg.getString("VendorCategory"); 
								log.info("vndcat  ::" + vndcat);
								
							}
							
							if ((lkpflag == null && (vndrtype.contains("MRO") || vndrtype.contains("Enterprise"))) || (lkpannspend == null && (vndrtype.contains("MRO") || vndrtype.contains("Enterprise"))) || (vndrcatg == null && (vndrtype.contains("MRO") || vndrtype.contains("Enterprise"))))
							{
								String validateCustomerError ="SIP-888801$Vendor Category, Annual Spend and commited Flag Cannot be Null";
								if (!isEmpty(validateCustomerError)) {
									dataFactory = helperContext.getDataFactory();
									List<ValidationError> custErrorList = new ArrayList<>();

									ValidationError custError = (ValidationError) dataFactory.create(ValidationError.class);
									custError.setCode(validateCustomerError.substring(0,	validateCustomerError.indexOf("$")));
									custError.setMessage(validateCustomerError.substring(validateCustomerError.lastIndexOf("$") + 1));
									if(businessentityName !=null  && businessentityName.equals("ExHFC_HEP_CustomerOrg")){
									custError.setField(Collections.singletonList("ExHFC_HEP_CustomerOrg.ExBusinessRelationship"));
									}
									custErrorList.add(custError);
									log.info("errorList ::" + custErrorList);
									ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
									errors.setError(custErrorList);
									throw new StepException((DataObject) errors,"SIP-50022");
								}
							}
							
						}
					}
				}
				
				
    	if (csList != null && !csList.isEmpty()) {
    		log.info("Change Summary size is "+csList.size());
    		for (int csindex = 0; csindex < csList.size(); csindex++) { 
    			DataObject csdo = (DataObject) csList.get(csindex);
//    	        String brRowid = br.getString("RemitTo/rowidObject");
//    	        log.info("Rowid Object of Business Rel DO "+brindex+" is "+brRowid);
//    			String sdoName = csdo.getType().getName();
//    			String sdoURI = csdo.getType().getURI();
//    			log.info("SDO Name is "+sdoName);
//    			log.info("SDO Type is "+sdoURI);
    			xml = helperContext.getXMLHelper().save(
    					csdo,
    					csdo.getType().getURI(),
    					csdo.getType().getName());
    	    	log.info("XML String of CS SDO "+csindex+"is "+xml);
    			String sdoName = csdo.getType().getName();
    			log.info("SDO Name is "+sdoName);
    			if(inputSdo.getChangeSummary().isCreated(csdo)) {
    				log.info(sdoName+" is Created");
    				csMap.put(sdoName+"-Created",csdo);
    				csCreatedList.add(sdoName);
    			}
    			if(inputSdo.getChangeSummary().isDeleted(csdo)) {
    				log.info(sdoName+" is Deleted");
    				csMap.put(sdoName+"-Deleted",csdo);
    				csDeletedList.add(sdoName);
    			}
    			if(inputSdo.getChangeSummary().isModified(csdo)) {
    				log.info(sdoName+" is Modified");
    				csMap.put(sdoName+"-Modified",csdo);
    				csModifiedList.add(sdoName);
    			}
    			
    	    }
    	}
    	log.info("Completed Printing Change Summary");
        
    	
    	List<ValidationError> errorList = new ArrayList<>();
    	
        ValidationError error = (ValidationError) dataFactory.create(ValidationError.class);
        ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
        
        log.info("Line before the WriteCO.AfterValidate check");
        if (inParams.get("servicePhase").toString().equals("WriteCO.AfterValidate")) {
        	log.info("Inside the service phase WriteCO.AfterValidate");
        	String errorData=null;
//        	inputSdo.getChangeSummary().beginLogging();
//        	inputSdo.setString("FullName", "Dummy Name");
//        	inputSdo.getChangeSummary().endLogging();
        	if (csList != null && !csList.isEmpty()) {
            	//New Vendor Creation Validation
    	        if (csCreatedList.contains("CustomerOrg.Root")) {
    	        	outParams.put("OperationType", "NewVendor");
    	        	//Business Relationship Validation
    	        	@SuppressWarnings("unchecked")
    				List<?> newBusinessRelList = inputSdo.getList("CustomerOrg/BusinessRelationship/item");
    	        	if ((newBusinessRelList == null) || newBusinessRelList.isEmpty()) {
    	        		errorData="CustomerOrg.BusinessRelationship";
    	        		errorData+=":";
    	        		errorData+="New Vendor should have atleast one Company Code Information";
    	        		errorData+="@";
    	        	}
    	        	// Tax Validation
    	        	@SuppressWarnings("unchecked")
    				List<?> newTaxList = inputSdo.getList("CustomerOrg/Tax/item");
    	        	if ((newTaxList == null) || newTaxList.isEmpty()) {
    	        		errorData+="CustomerOrg.Tax";
    	        		errorData+=":";
    	        		errorData+="New Vendor should have atleast one Tax Information";
    	        		errorData+="@";
    	        	}
    	        	// Tax Validation
    	        	@SuppressWarnings("unchecked")
    				List<?> newMiscList = inputSdo.getList("CustomerOrg/Miscellaneous/item");
    	        	if ((newMiscList == null) || newMiscList.isEmpty()) {
    	        		errorData+="CustomerOrg.Miscellaneous";
    	        		errorData+=":";
    	        		errorData+="New Vendor should have Miscellaneous Information";
    	        	}
    	        	
    	        
    	        }
    	        //Change Vendor Validations
    	        else {
    	        	outParams.put("OperationType", "ChangeVendor");
    	        	//Remit To Address Change
    	        	if(csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToAddress")) {
    	            	log.info("Remit To Address has been changed");
    	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    	            		log.info("Active Request is not Available");
    	            		errorData="CustomerOrg.Request";
        	        		errorData+=":";
        	        		errorData+="No Active Request for Remit To Address Change";
        	        		errorData+="@";
    	            	}
    	            	else {
    	            		log.info("Active Request is Available");
    	            		String isAddressChangeSelected = null;
    	            		isAddressChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("AddressChange");
    	            		if(isAddressChangeSelected == null || isAddressChangeSelected.isEmpty()) {
    	            			log.info("Active Request is not having Remit To Address Change - 1");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Remit To Address Change";
            	        		errorData+="@";
    	            			
    	            		}
    	            		else if(!isAddressChangeSelected.equals("1")) {
    	            			log.info("Active Request is not having Remit To Address Change - 2");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Remit To Address Change";
            	        		errorData+="@";
    	            			
    	            		}
    	            			
    	            	}
    	            }
    	        	//Remit To Banking Change
    	            if(csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToBank")) {
    	            	log.info("Remit To Banking has been changed");
    	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    	            		log.info("Active Request is not Available");
    	            		errorData+="CustomerOrg.Request";
        	        		errorData+=":";
        	        		errorData+="No Active Request for Remit To Banking Change";
        	        		errorData+="@";
    	            	  
    	            	}
    	            	else {
    	            		log.info("Active Request is Available");
    	            		String isBankingChangeSelected = null;
    	            		isBankingChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("BankingChange");
    	            		if(isBankingChangeSelected == null || isBankingChangeSelected.isEmpty()) {
    	            			log.info("Active Request is not having Remit To Banking Change - 1");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Remit To Banking Change";
            	        		errorData+="@";
    	            			
    	            		}
    	            		else if(!isBankingChangeSelected.equals("1")) {
    	            			log.info("Active Request is not having Remit To Banking Change - 2");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Remit To Banking Change";
            	        		errorData+="@";
    	            			
    	            		}
    	            			
    	            	}
    	            }
    	            //Remit To Payment Details
    	            if(csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails")) {
    	            	log.info("Remit To Payment Details has been changed");
    	            	String isPaymentTermChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentTerm/PaymentTermCd");
    	            	String isPaymentMethodChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentMethod/PaymentMethodCd");
    	            	//Payment Term Change
    	            	if(isPaymentTermChanged == null || isPaymentTermChanged.isEmpty()) {
    		            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    		            		log.info("Active Request is not Available");
    		            		errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="No Active Request for Remit To Payment Term Change";
            	        		errorData+="@";
    		            	  
    		            	}
    		            	else {
    		            		log.info("Active Request is Available");
    		            		String isPaymentTermChangeSelected = null;
    		            		isPaymentTermChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("PaymentTermChange");
    		            		if(isPaymentTermChangeSelected == null || isPaymentTermChangeSelected.isEmpty()) {
    		            			log.info("Active Request is not having Remit To Payment Details Change - 1");
    		            			errorData+="CustomerOrg.Request";
    	        	        		errorData+=":";
    	        	        		errorData+="Active Request is not having Remit To Payment Details Change";
    	        	        		errorData+="@";
    		            			
    		            		}
    		            		else if(!isPaymentTermChangeSelected.equals("1")) {
    		            			log.info("Active Request is not having Remit To Payment Details Change - 2");
    		            			errorData+="CustomerOrg.Request";
    	        	        		errorData+=":";
    	        	        		errorData+="Active Request is not having Remit To Payment Details Change";
    	        	        		errorData+="@";
    		            			
    		            		}
    		            			
    		            	}
    	            	}
    	            	//Payment Method Change
    	            	if(isPaymentMethodChanged == null || isPaymentMethodChanged.isEmpty()) {
    		            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    		            		log.info("Active Request is not Available");
    		            		errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="No Active Request for Remit To Payment Method Change";
            	        		errorData+="@";
    		            	  
    		            	}
    		            	else {
    		            		log.info("Active Request is Available");
    		            		String isPaymentTermChangeSelected = null;
    		            		isPaymentTermChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("PaymentChange");
    		            		if(isPaymentTermChangeSelected == null || isPaymentTermChangeSelected.isEmpty()) {
    		            			log.info("Active Request is not having Remit To Payment Method Change - 1");
    		            			errorData+="CustomerOrg.Request";
    	        	        		errorData+=":";
    	        	        		errorData+="Active Request is not having Remit To Payment Method Change";
    	        	        		errorData+="@";
    		            			
    		            		}
    		            		else if(!isPaymentTermChangeSelected.equals("1")) {
    		            			log.info("Active Request is not having Remit To Payment Method Change - 2");
    		            			errorData+="CustomerOrg.Request";
    	        	        		errorData+=":";
    	        	        		errorData+="Active Request is not having Remit To Payment Method Change";
    	        	        		errorData+="@";
    		            			
    		            		}
    		            			
    		            	}
    	            	}
    	            }
    	            // Order From Address Change
    	            if(csModifiedList.contains("CustomerOrg.BusinessRelationship.OrderFrom.OrderFromAddress")) {
    	            	log.info("Order From Address has been changed");
    	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    	            		log.info("Active Request is not Available");
    	            		errorData+="CustomerOrg.Request";
        	        		errorData+=":";
        	        		errorData+="No Active Request for Order From Address Change";
        	        		errorData+="@";
    	            	  
    	            	}
    	            	else {
    	            		log.info("Active Request is Available");
    	            		String isAddressChangeSelected = null;
    	            		isAddressChangeSelected = csMap.get("CustomerOrg.Request-Created").getString("AddressChange");
    	            		if(isAddressChangeSelected == null || isAddressChangeSelected.isEmpty()) {
    	            			log.info("Active Request is not having Order From Address Change - 1");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Order From Address Change";
            	        		errorData+="@";
    	            			
    	            		}
    	            		else if(!isAddressChangeSelected.equals("1")) {
    	            			log.info("Active Request is not having Order From Address Change - 2");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Order From Address Change";
            	        		errorData+="@";
    	            			
    	            		}
    	            			
    	            	}
    	            }
    	            // Additional Order From
    	            if(csCreatedList.contains("CustomerOrg.BusinessRelationship.OrderFrom")) {
    	            	log.info("Additional Order From Address has been Created");
    	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    	            		log.info("Active Request is not Available");
    	            		errorData+="CustomerOrg.Request";
        	        		errorData+=":";
        	        		errorData+="No Active Request for Additional Order From";
        	        		errorData+="@";
    	            	  
    	            	}
    	            	else {
    	            		log.info("Active Request is Available");
    	            		String isAdditionalOFSelected = null;
    	            		isAdditionalOFSelected = csMap.get("CustomerOrg.Request-Created").getString("AdditionalOF");
    	            		if(isAdditionalOFSelected == null || isAdditionalOFSelected.isEmpty()) {
    	            			log.info("Active Request is not having Additional Order From - 1");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Additional Order From";
            	        		errorData+="@";
    	            			
    	            		}
    	            		else if(!isAdditionalOFSelected.equals("1")) {
    	            			log.info("Active Request is not having Additional Order From - 2");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Additional Order From";
            	        		errorData+="@";
    	            			
    	            		}
    	            			
    	            	}
    	            }
    	            //Additional Remit To
    	            if(csCreatedList.contains("CustomerOrg.BusinessRelationship.RemitTo")) {
    	            	log.info("Additional Remit To Address has been Created");
    	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    	            		log.info("Active Request is not Available");
    	            		errorData+="CustomerOrg.Request";
        	        		errorData+=":";
        	        		errorData+="No Active Request for Additional Remit To";
        	        		errorData+="@";
    	            	  
    	            	}
    	            	else {
    	            		log.info("Active Request is Available");
    	            		String isAdditionalRTSelected = null;
    	            		isAdditionalRTSelected = csMap.get("CustomerOrg.Request-Created").getString("AdditionalRT");
    	            		if(isAdditionalRTSelected == null || isAdditionalRTSelected.isEmpty()) {
    	            			log.info("Active Request is not having Additional Remit To - 1");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Additional Remit To";
            	        		errorData+="@";
    	            			
    	            		}
    	            		else if(!isAdditionalRTSelected.equals("1")) {
    	            			log.info("Active Request is not having Additional Remit To - 2");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Additional Remit To";
            	        		errorData+="@";
    	            			
    	            		}
    	            			
    	            	}
    	            }
    	            //Extend Vendor
    	            if(csCreatedList.contains("CustomerOrg.BusinessRelationship")) {
    	            	log.info("New Business Relationship has been Created");
    	            	if(!csCreatedList.contains("CustomerOrg.Request")) {
    	            		log.info("Active Request is not Available");
    	            		errorData+="CustomerOrg.Request";
        	        		errorData+=":";
        	        		errorData+="No Active Request for Extend Vendor";
        	        		errorData+="@";
    	            	}
    	            	else {
    	            		log.info("Active Request is Available");
    	            		String isExtendVendorSelected = null;
    	            		isExtendVendorSelected = csMap.get("CustomerOrg.Request-Created").getString("ExtendVendor");
    	            		if(isExtendVendorSelected == null || isExtendVendorSelected.isEmpty()) {
    	            			log.info("Active Request is not having Extend Vendor - 1");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Extend Vendor";
            	        		errorData+="@";
    	            		}
    	            		else if(!isExtendVendorSelected.equals("1")) {
    	            			log.info("Active Request is not having Extend Vendor - 2");
    	            			errorData+="CustomerOrg.Request";
            	        		errorData+=":";
            	        		errorData+="Active Request is not having Extend Vendor";
            	        		errorData+="@";
    	            		}
    	            			
    	            	}
    	            }
    	            //Request to Change Validation
    	            if(csCreatedList.contains("CustomerOrg.Request")) {
    	            	DataObject requestDO = csMap.get("CustomerOrg.Request-Created");
    		            String additionalRT = requestDO.getString("AdditionalRT");
    		            String additionalOF = requestDO.getString("AdditionalOF");
    		            String addressChange = requestDO.getString("AddressChange");
    		            String paymentTermChange = requestDO.getString("PaymentTermChange");
    		            String paymentMethodChange = requestDO.getString("PaymentChange");
    		            String extendVendor = requestDO.getString("ExtendVendor");
    		            String bankingChange = requestDO.getString("BankingChange");
    		            // Additional Remit To Ticket with No new Remit To
    		            if(!(additionalRT == null || additionalRT.isEmpty())) {
    		            	if ( additionalRT.equals("1")) {
    		            		if ( !csCreatedList.contains("CustomerOrg.BusinessRelationship.RemitTo")) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Additional Remit To Option Checked but No new Remit To Details has been added";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    		            // Additional Order From Ticket with No new Order From
    		            if(!(additionalOF == null || additionalOF.isEmpty())) {
    		            	if ( additionalOF.equals("1")) {
    		            		if ( !csCreatedList.contains("CustomerOrg.BusinessRelationship.OrderFrom")) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Additional Order From Option Checked but No new Order From Details has been added";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    		            // Address Change Ticket with No Address Change
    		            if(!(addressChange == null || addressChange.isEmpty())) {
    		            	if ( addressChange.equals("1")) {
    		            		if ( !csModifiedList.contains("CustomerOrg.BusinessRelationship.OrderFrom.OrderFromAddress") && !csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToAddress" )) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Address Change Option Checked but No Address Details has been Changed";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    		            // Payment Term Ticket with No Payment Term Change
    		            if(!(paymentTermChange == null || paymentTermChange.isEmpty())) {
    		            	if ( paymentTermChange.equals("1")) {
    		            		String isPaymentTermChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentTerm/PaymentTermCd");
    		            		if ( isPaymentTermChanged == null || isPaymentTermChanged.isEmpty()) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Payment Term Change Option Checked but No Payment Term Details has been Changed";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    		            // Payment Method Ticket with No Payment Method Change
    		            if(!(paymentMethodChange == null || paymentMethodChange.isEmpty())) {
    		            	if ( paymentMethodChange.equals("1")) {
    		            		String isPaymentMethodChanged = csMap.get("CustomerOrg.BusinessRelationship.RemitTo.PaymentDetails-Modified").getString("PaymentMethod/PaymentMethodCd");
    		            		if ( isPaymentMethodChanged == null || isPaymentMethodChanged.isEmpty()) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Payment Method Change Option Checked but No Payment Method Details has been Changed";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    		            // Extend Vendor Ticket with No new Business Rel Record
    		            if(!(extendVendor == null || extendVendor.isEmpty())) {
    		            	if ( extendVendor.equals("1")) {
    		            		if ( !csCreatedList.contains("CustomerOrg.BusinessRelationship")) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Extend Vendor Option Checked but No new Extend Vendor Details has been added";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    		            // Banking Change Ticket with No Banking Information Changed
    		            if(!(bankingChange == null || bankingChange.isEmpty())) {
    		            	if ( bankingChange.equals("1")) {
    		            		if ( !csModifiedList.contains("CustomerOrg.BusinessRelationship.RemitTo.RemitToBank")) {
    		            			errorData+="CustomerOrg.Request";
                	        		errorData+=":";
                	        		errorData+="Active Request has Banking Change Option Checked but no Banking Details has been Changed";
                	        		errorData+="@";
    		            			
    		            		}
    		            	}
    		            }
    	            }
    	        }
    	        if (errorData != null && !errorData.equals(null)) {
    	        outParams.put("errorData", errorData);
    	        }
        	}
        	log.info("outparams are populated with final SDO");
        }
        
        if (inParams.containsKey("interactionId") || inParams.containsKey("processId")) {
        	log.info("Interaction Id or Process Id is not Null");
        	if (inParams.containsKey("OperationType")) {
        		if (inParams.get("OperationType").equals("NewVendor")) {
        			if (inParams.containsKey("errorData")) {
        				String errorData = inParams.get("errorData").toString();
        				log.info(errorData);
        				String[] errorArr = errorData.split("@");
        				for ( String oneError : errorArr) {
        					log.info(oneError);
        					String errorEntity = oneError.split(":")[0];
        					String errorMsg = oneError.split(":")[1];
        					log.info(errorEntity);
        					log.info(errorMsg);
        					error.setCode("CUSTOM-NEWVENDOR");
                            error.setMessage(errorMsg);
                            error.setField(Collections.singletonList(errorEntity));
                            errorList.add(error);
        				}
        				log.info("Throwing Exception after Save");
        				errors.setError(errorList);
                        throw new StepException((DataObject) errors, "SIP-50022");
        			}
        		}
        		else if (inParams.get("OperationType").equals("ChangeVendor")) {
        			if (inParams.containsKey("errorData")) {
        				String errorData = inParams.get("errorData").toString();
        				log.info(errorData);
        				String[] errorArr = errorData.split("@");
        				for ( String oneError : errorArr) {
        					log.info(oneError);
        					String errorEntity = oneError.split(":")[0];
        					String errorMsg = oneError.split(":")[1];
        					log.info(errorEntity);
        					log.info(errorMsg);
        					error.setCode("CUSTOM-CHGVENDOR");
                            error.setMessage(errorMsg);
                            error.setField(Collections.singletonList(errorEntity));
                            errorList.add(error);
        				}
        				log.info("Throwing Exception after Save");
        				errors.setError(errorList);
                        throw new StepException((DataObject) errors, "SIP-50022");
        			}
        		}
        		
        	}
        }
        log.info("Ending of the service phase");
		return null;
	}




}
